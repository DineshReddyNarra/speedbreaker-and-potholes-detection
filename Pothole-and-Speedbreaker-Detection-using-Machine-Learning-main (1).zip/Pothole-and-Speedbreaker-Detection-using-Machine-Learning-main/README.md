# **Pothole and SpeedBreaker detection on Raspberry Pi 4**
The project aims to alert and reduce the number of accidents which are caused by the potholes and speedbreakers.














